from os.path import isfile
import numpy
import re
import mes

		
			

if __name__ == "__main__":
    nazwaProjektu = "ht_1"
    #nazwaProjektu = input("Wprowadź nazwę projektu [default test]")
    zad = mes.Zadanie()
    zad.wczytaj_msh(nazwaProjektu)
    zad.wypisz_wczytany_msh()
    zad.wczytaj_m(nazwaProjektu)
    zad.wypisz_m()
    zad.wczytaj_ic(nazwaProjektu)
    zad.wypisz_ic()
    zad.wczytaj_bc(nazwaProjektu)
    zad.wypisz_bc()
    zad.zrob_obiekty()
    zad.wypisz_obiekty()

#from os.path import isfile


#class WarunekBrzegowyIII :
#	def __init__(self, w1, w2, temp, alfa):
	
#		# Indeksy wezlow
#		self.w1 = w1
#		self.w2 = w2
		
#		# Temperatura otoczenia
#		self.temp = temp
		
#		# Wspolczynnik wymiany ciepla z otoczeniem
#		self.alfa = alfa
	
#class Zadanie:

#	def __init__(self):
#		self.obszary = []
#		self.t = 0

#	def wczytaj(self,plik):

#		obszar = Obszar()
	
#		tryb = 0
#		f = open(plik, "r+")
#		for l in f:
#			if (l == '[WSPOLRZEDNE WEZLOW]\n'):
#				tryb = 1
#			elif (l == '[KONEKSJE]\n'):
#				tryb = 2    
#			elif (l == '[BRZEGI]\n'):
#				tryb = 3  
				
#			elif (tryb == 1) :
#				if ( l=='\n') : 
#					tryb = 0
#				else:
#					t = l.split("  ")
#					tmp = [float(t[1]), float(t[2])]
#					obszar.wspolrzedneWezlow.append(tmp)
					
#			elif (tryb == 2) :
#				if (l=='\n') : 
#					tryb = 0
#				else:
#					t = l.split(" ")
#					# Odejmujemy jedynke, zeby numery indekow sie zgadzaly
#					tmp = [int(t[2])-1, int(t[3])-1, int(t[4])-1]
#					obszar.koneksje.append(tmp)
					
#			elif (tryb == 3) :
#				if (l=='\n') : 
#					tryb = 0
#				else:
#					tryb = 4
				
#			elif (tryb == 4) :
#				if (l=='\n') : 
#					tryb = 3
#				else:
#					t = l.split(" ")
#					# Odejmujemy jedynke, zeby numery indekow sie zgadzaly
#					tmp = [int(t[0])-1, int(t[1])-1]
#					obszar.brzegi.append(tmp)
					
#		self.obszary.append(obszar)
					
#	def wczytaj_warunki_poczatkowe(self,plik) :
#		#TODO: Wczytac warunki poczatkowe z pliku - na razie sa na sztywno
#		self.obszary[0].T = numpy.zeros((len(self.obszary[0].wspolrzedneWezlow), 1))
#		self.obszary[0].T += 600.0
		
#		#self.T[0] = self.T[1]  = 300.0
		
#	def wczytaj_warunki_brzegowe(self, plik) :
#		#TODO: Wczytac warunki brzegowe z pliku - na razie sa na sztywno
#		b = WarunekBrzegowyIII(3, 4, 300.0, 1000.0)
#		self.obszary[0].warunkiBrzegowe.append(b)
		
#	def utworz_macierze(self):
#		for obszar in self.obszary :
#			obszar.utworz_macierz()
			
#	def wypisz_temp(self) :
#		for obszar in self.obszary :
#			print(obszar.T)
					
#	def wypisz(self) :
#		for obszar in self.obszary :
#			obszar.wypisz()
		
#	def krok(self, dt) :
#		self.t += dt
#		for obszar in self.obszary :
#			obszar.krok(dt)
			


#if __name__ == "__main__":

#	mes = Zadanie()
#	mes.wczytaj("test.msh")
#	mes.wczytaj_warunki_poczatkowe("test.ic")
#	mes.wczytaj_warunki_brzegowe("test.bc")
#	mes.utworz_macierze()    
#	mes.wypisz()
	
#	for i in range(1000) :
#		mes.krok(1)
	
#	print("Temperatura po czasie " + str(mes.t) + " s")
#	mes.wypisz_temp()
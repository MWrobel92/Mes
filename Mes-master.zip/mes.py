from os.path import isfile
import numpy
import re
from Obszar import Obszar

class Zadanie:
    def __init__(self):
        self.obszary_obiekty = []

        self.wspolrzedneWezlow = []
        self.koneksje = []
        self.brzegi = []
        self.obszary = []
        self.liczbaWymiarow = 2
        self.liczbaWezlow = 0
        self.liczbaElementow = 0
        self.liczbaBrzegow = 0
        self.liczbaObszarow = 0
        self.warunkiBrzegowe = []
        self.warunkiPoczatkowe = []
        # Macierz masowa
        self.macierzM = [[]]    
        # Macierz sztywnosci
        self.macierzK = [[]]
        #Własności materiałowe
        self.wlasnosciMaterialowe = []

        #TODO: Ponizsze wartosci powinny byc wczytywane z pliku
        # Gestosc
        self.p = 7.700000e+003
        # Cieplo wlasciwe
        self.c = 8.000000e+002
        # Przewodzenie ciepla
        self.l = 4.000000e+001
        # Aktualna temperatura
        self.T = [[]]
        # Aktualny czas
        self.t = 0


    def wczytaj_msh (self,fname):
        u""" Funkcja do wycztytania danych z pliku mes nazwa pliku bez rozszerzenia"""
        fname = fname + ".msh"
        f = open(fname,"r+")
        lines = f.readlines()
        ilWierszy = len(lines)-1
        i = 0
        while i < ilWierszy:
            j = 0
            if lines[i] == "\n":
                i += 1
                continue
            elif lines[i] == "[LICZBA WYMIAROW]\n":
                self.liczbaWymiarow = int(lines[i+1])
                i += 2
            elif lines[i] == "[LICZBA WEZLOW]\n":
                self.liczbaWezlow = int(lines[i+1])
                i += 2
            elif lines[i] == "[LICZBA ELEMENTOW]\n":
                self.liczbaElementow = int(lines[i+1])
                i += 2			
            elif lines[i] == "[LICZBA BRZEGOW]\n":
                self.liczbaBrzegow = int(lines[i+1])
                i += 2
            elif lines[i] == "[LICZBA OBSZAROW]\n":
                self.liczbaObszarow = int(lines[i+1])
                i += 2
            elif lines[i] == "[WSPOLRZEDNE WEZLOW]\n":
                i += 1
                for j in range(self.liczbaWezlow):
                    row = lines[i+j].split()
                    for k in range(len(row)):
                        row[k] = float(row[k])
                    self.wspolrzedneWezlow.append(row)
                i = i + self.liczbaWezlow
            elif lines[i] == '[KONEKSJE]\n':
                i = i + 1
                for j in range(ilWierszy-i):
                    if lines[i+j][0] == "[":
                        i += j
                        break
                    elif lines[i+j] == '\n':
                        continue
                    else:
                        row = lines[i+j].split()
                        for k in range(2,len(row)):
                            row[k] = int(row[k])
                        self.koneksje.append(row)
            elif lines[i] == '[BRZEGI]\n':
                i = i + 1
                while j < (ilWierszy-i):
                    if lines[i+j][0] == "[":
                        i += j
                        break
                    elif lines[i+j] == '\n':
                        j += 1
                        continue
                    else:
                        row = lines[i+j].split()
                        row.extend(lines[i+j+1].split())
                        for k in range(len(row)):
                            row[k] = int(row[k])
                        self.brzegi.append(row)
                        j += 3
            elif lines[i] == '[OBSZARY]\n':
                i = i + 1
                koniec = ilWierszy-i-1
                for j in range(koniec):
                    if lines[i+j] == '\n':
                        continue
                    else:
                        row = lines[i+j].split()
                        row.extend(lines[i+j+1].split())
                        for k in range(len(row)):
                            try:
                                row[k] = int(row[k])
                            except:
                                pass
                        self.obszary.append(row)
                        i = i + 1
            else:
                i += 1
        f.close()

    def wypisz_wczytany_msh(self):
        print ('[LICZBA WYMIAROW]: ' , self.liczbaWymiarow)
        print ('[LICZBA WEZLOW]: ' , self.liczbaWezlow)		
        print ('[LICZBA ELEMENTOW]: ' , self.liczbaElementow)		
        print ('[LICZBA BRZEGOW]: ' , self.liczbaBrzegow)	
        print ('[LICZBA OBSZAROW]: ' , self.liczbaObszarow)		
        print ('[WSPOLRZEDNE WEZLOW]: ' ,*self.wspolrzedneWezlow,sep="\n")
        print ('[KONEKSJE]: ', *self.koneksje, sep="\n")
        print ('[BRZEGI]: ', *self.brzegi, sep="\n")
        print ('[OBSZARY]: ', *self.obszary, sep="\n")

    def weryfikuj_linie_naglowkowa(self,liniaDoAnalizy):
        tmp = liniaDoAnalizy.split()
        if len(tmp) == 5:
            try:
                if int(tmp[0]) == self.liczbaWymiarow and int(tmp[1]) == self.liczbaWezlow and int(tmp[2]) == self.liczbaElementow and int(tmp[3]) == self.liczbaObszarow and int(tmp[4]) == self.liczbaBrzegow :
                    return 1
            except:
                return 0
        else:
            return 1



    def wczytaj_m (self,fname):
        fname += ".m"
        f = open(fname,"r+")
        lines = f.readlines()
        i = 0
        j = 0 
        row = []

        while i < len(lines):
            if lines[i] == "\n":
                i += 1
                continue
            elif not(re.search("^\d",lines[i])):
                i += 1
                continue
            elif lines[i] == '101\n':
                iloscParametrow = int(lines[i+1])
                i += 2
                while j < iloscParametrow:
                    row.append(float(lines[i+1]))
                    i += 3
                    j += 1
                self.wlasnosciMaterialowe.append(row)
                row = []
                j = 0
            else:
                i += 1

    def wczytaj_ic (self,fname):
        fname += ".ic"
        f = open(fname,"r+")
        lines = f.readlines()
        i = 0
        j = 0 
        row = []

        while i < len(lines):
            if lines[i] == "\n":
                i += 1
                continue
            elif not(re.search("^\d",lines[i])):
                i += 1
                continue
            elif lines[i] == '0\n':
                self.warunkiPoczatkowe = lines[i+1].split()
                for j in range(len(self.warunkiPoczatkowe)):
                    self.warunkiPoczatkowe[j] = float(self.warunkiPoczatkowe[j])
                break
            elif self.weryfikuj_linie_naglowkowa(lines[i]):
                i += 1
                continue
            else:
                i += 1

    def wypisz_ic (self):   
        print("[WARUNKI POCZĄTKOWE]")
        print (self.warunkiPoczatkowe)

    def wczytaj_bc (self,fname):
        fname += ".bc"
        f = open(fname,"r+")
        lines = f.readlines()
        i = 0
        j = 0 
        row = []
        tryb = 0
        ilBrzegow = 0
        ilParametrow = 0
        nrBrzegu = 0
        tmp = []

        while i < len(lines):
            if lines[i] == "\n": # pusta linia
                i += 1
                continue
            elif not(re.search("^\d",lines[i])): #omiń tekst i komentarze
                i += 1
                continue
            elif tryb == 1: # porawny plik i wyciągnięta ilość warunków pocz.
                row = lines[i].split()
                if int(row[3]) == 0:
                    i += 2
                    continue
                else:
                    tmp.append(int(row[0])) #nr brzegu
                    i += 1
                    row = lines[i].split()
                    ilParametrow = int(row[3])
                    i += 3
                    for j in range(ilParametrow):
                        tmp.append(float(lines[i]))
                        i += 2
                    self.warunkiBrzegowe.append(tmp)
                    tmp = []

            elif self.weryfikuj_linie_naglowkowa(lines[i]) and tryb == 0:
                tryb = 1
                ilBrzegow = int(lines[i+2])
                i += 3
                continue
            else:
                i += 1
    def wypisz_bc (self):
        print("[WARUNKI BRZEGOWE]")
        print(self.warunkiBrzegowe)

    def wypisz_m(self):
        i = 0
        print ("[WARUNKI MATERIAŁOWE]")
        while i < len(self.wlasnosciMaterialowe):
           j = 0
           while j < len(self.wlasnosciMaterialowe[i]):
               if j == 0: print("[" + str(i) + "] Gestosc: " + str(self.wlasnosciMaterialowe[i][j]))
               elif j == 1: print("[" + str(i) + "] Cieplo wlasciwe: " + str(self.wlasnosciMaterialowe[i][j]))
               elif j == 2: print("[" + str(i) + "] Aktualna temperatura: " + str(self.wlasnosciMaterialowe[i][j]))
               else: print("[" + str(i) + "] Nieokreślony parametr: " + str(self.wlasnosciMaterialowe[i][j]))
               j += 1
           i += 1

    def zrob_obiekty(self) :
        for ob in self.obszary :
            nowy = Obszar()
            nowy.nazwa = ob[2]
            self.obszary_obiekty.append(nowy)

        for wz in self.wspolrzedneWezlow :
            for ob in self.obszary_obiekty :
                ob.wspolrzedneWezlow.append([wz[1], wz[2]])

        for kon in self.koneksje :
            id_obszaru = kon[-1]-1
            self.obszary_obiekty[id_obszaru].koneksje.append([kon[2]-1,kon[3]-1,kon[4]-1])

        for br in self.brzegi :
            id_obszaru = br[2]-1
            self.obszary_obiekty[id_obszaru].brzegi.append(numpy.add(br[3:],-1))

        for i in range(len(self.obszary_obiekty)) :
            self.obszary_obiekty[i].p = self.wlasnosciMaterialowe[i][0]
            self.obszary_obiekty[i].c = self.wlasnosciMaterialowe[i][1]
            self.obszary_obiekty[i].l = self.wlasnosciMaterialowe[i][2]

        for ob in self.obszary_obiekty :
            ob.utworz_macierz()
            ob.T = numpy.zeros(len(ob.ws))

    def wypisz_obiekty(self) :
        for ob in self.obszary_obiekty :
            ob.wypisz()
